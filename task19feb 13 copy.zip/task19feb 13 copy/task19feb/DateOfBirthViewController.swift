//
//  DateOfBirthViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit
import CoreData

class DateOfBirthViewController: UIViewController {

    @IBOutlet weak var txtDOB: UITextField!
    let a = 1
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func saveData(_ sender: Any) {
        
    
        
        if txtDOB.text!.isDateOfBirthValid {
            print("DateOf Birth is valid ")
            someDict["DOB"] = txtDOB.text!
        }
        else {
            
            let alert = UIAlertController(title: "incorrect", message: "please enter the Date Of Birth in this formate  dd/mm/yyyy ", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                self.present(alert, animated: true, completion: nil)
            
        }
        
        print(someDict)
        print("hello")
        
       let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity1 = NSEntityDescription.entity(forEntityName: "UserLoginTwo", in: context)
        let newUser = NSManagedObject(entity: entity1! , insertInto: context)
        newUser.setValue(someDict["FastName"], forKey: "firstName")
        newUser.setValue(someDict["LastName"], forKey: "lastName")
        newUser.setValue(someDict["Email"], forKey: "email")
        newUser.setValue(someDict["Password"], forKey: "password")
        newUser.setValue(someDict["DOB"], forKey: "dob")
        newUser.setValue(someDict["Phone"], forKey: "phone")
        
        do {
            try context.save()
        } catch {
            print("Failed saving")
        }
       let vc = self.storyboard?.instantiateViewController(withIdentifier: "EmailTableViewController") as! EmailTableViewController
       self.navigationController?.pushViewController(vc, animated: true)
       
        
    }
}

