//
//  ViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //    MARK:- outlets
    @IBOutlet weak var txtEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getEmailData()
        print(emailGetData)
        // Do any additional setup after loading the view.
//        getEmailData()
//        for data in  emailGetData {
//            if( data == txtEmail.text ) {
//                let alert = UIAlertController(title: "Alert", message: "Please enter voild email this email is already register code", preferredStyle: UIAlertController.Style.alert)
//                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
//                self.present(alert, animated: true, completion: nil)
//
//            }
//        }
        
    }
    @IBAction func alertaction(_ sender: Any) {
        let alert = UIAlertController(title: "Showing Register User", message: "Enter volid UserName", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Input User name here..."
        })
//
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
//            if let name = alert.textFields?.first?.text {
//                print("Your name: \(name)")
//            }
//        })
    }
    
    
    @IBAction func next1(_ sender: Any) {
        
        
        if txtEmail.text!.isValidEmail {
            print("email is valid ")
            someDict["Email"] = txtEmail.text!
            getEmailData()
          for email in emailGetData{
            if txtEmail.text == email {
                print("pass")
            
            
            let alert = UIAlertController(title: "incorrect", message: "your email id is already register please enter password in", preferredStyle: UIAlertController.Style.alert)
    
            alert.addTextField(configurationHandler: { textField in
                       textField.placeholder = "Enter currrect password here..."
                   })
                guard let vc = storyboard?.instantiateViewController(identifier: "ShowAllDataViewController") as? ShowAllDataViewController else { return }

                   alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in

                       if let name = alert.textFields?.first?.text {
                        print(name)
                        var i = -1
                        for password in passwordGetData{
                            i = i+1
                        if name == password {
                       vc.ind = i
                        self.present(vc, animated: true, completion: nil)
                    }
                        else {
                            print("wrong password")
                            }
                        }}
            }))
                self.present(alert, animated: true, completion: nil)
        
    }
        }
        }
        
                    
        else {
            
            let alert = UIAlertController(title: "incorrect", message: "your email id is invalid please enter currect email id in", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                self.present(alert, animated: true, completion: nil)
            
        }
        getEmailData()
        
       
        
            
            
           
            
                 
        

        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}

