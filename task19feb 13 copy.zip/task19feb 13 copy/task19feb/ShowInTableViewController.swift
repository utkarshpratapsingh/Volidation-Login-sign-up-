//
//  ShowInTableViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit

class ShowInTableViewController: UITableViewController {
 
   
    @IBOutlet  var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self as? UITableViewDelegate
        tableView.dataSource = self as? UITableViewDataSource

        // Do any additional setup after loading the view.
    }
    

   
}
