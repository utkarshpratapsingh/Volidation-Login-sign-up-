//
//  PasswordViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit
import CoreData

class PasswordViewController: UIViewController {

    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func next5(_ sender: Any) {
        
        
        if txtPassword.text!.isPasswordValid {
                  print("password is valid ")
                  someDict["Password"] = txtPassword.text!
              }
              else {
                  
                  let alert = UIAlertController(title: "incorrect", message: "your password  is not too much stronger please make it stronger . Use special symble a -z A- Z and numerical value", preferredStyle: UIAlertController.Style.alert)
                  alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                      self.present(alert, animated: true, completion: nil)
                  
              }
               
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DateOfBirthViewController") as! DateOfBirthViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    

}
