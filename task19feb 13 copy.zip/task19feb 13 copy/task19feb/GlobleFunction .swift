//
//  GlobleFunction .swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import Foundation
import CoreData
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

var emailGetData = [String]()
var nameGetData = [String]()
var lastGetData = [String]()
var passwordGetData = [String]()
var phoneData = [String]()
var dobGetData = [String]()

var someDict = ["FastName": "String",
                "LastName": "String",
                "Email": "String",
                "Password": "String",
                "Phone": "Int",
                "DOB": "String"
    ] as [String : Any]


var singleRow = [String]()



func getEmailData() {
     let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserLoginTwo")
       request.returnsObjectsAsFaults = false
    
       do {
        let result = try context.fetch(request)
        emailGetData = []
        nameGetData = []
        lastGetData = []
        passwordGetData = []
        phoneData = []
        dobGetData = []
           for data in result as! [NSManagedObject] {
        
             emailGetData.append((data.value(forKey: "email") as? String)!)
            nameGetData.append((data.value(forKey: "firstName") as? String)!)
            lastGetData.append((data.value(forKey: "lastName") as? String)!)
            passwordGetData.append((data.value(forKey: "password") as? String)!)
           phoneData.append((data.value(forKey: "phone") as? String)!)
            dobGetData.append((data.value(forKey: "dob") as? String)!)
           }
       } catch {
           print(error)
       }
    
}

//MARK:- String Validation

extension String {

var isPhoneNumber: Bool {

do {

let detector = try NSDataDetector(types:NSTextCheckingResult.CheckingType.phoneNumber.rawValue)

let matches = detector.matches(in: self, options: [],  range: NSMakeRange(0,self.count))

if let res = matches.first {

return res.resultType == .phoneNumber && res.range.location  == 0  &&  res.range.length == self.count && self.count == 10

}

else

{

return false

}

} catch {

return false

}

}

var isPasswordValid: Bool{

let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")

return passwordTest.evaluate(with: self)

}

var isValidEmail: Bool {

let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{3}"

let  emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)

return emailTest.evaluate(with: self)

}
    var isName: Bool {
      let firstRegEx = "[a-zA-Z]+\\.?"

        let  emailTest = NSPredicate(format: "SELF MATCHES %@", firstRegEx)

        return emailTest.evaluate(with: self)

    }
    var isDateOfBirthValid: Bool {
        let dobRegEx =   "^(0[1-9]|1[012])[-/.](0[1-9]|[12][0-9]|3[01])[-/.](19|20)\\d\\d$"

          let  emailTest = NSPredicate(format: "SELF MATCHES %@", dobRegEx)

          return emailTest.evaluate(with: self)

      }
    

}


func deleteRowFormTable(email: String) -> Bool{
    let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserLoginTwo")
       request.returnsObjectsAsFaults = false
       do {
        let result = try context.fetch(request)
           for data in result as! [NSManagedObject] {
               if data.value(forKey: "email") as! String == email {
                context.delete(data)
                   do {
                    try context.save()
                       return true
                   } catch {
                       print (error)
                       return false
                   }
               }
           }
       } catch {
           print(error)
           return false
       }
       return false
}

        
    //MARK:- NoOfRowsInPersonTable
    func numberOfRowsInPersonTable() -> Int {
        var count = 0
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserLoginTwo")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for _ in result as! [NSManagedObject] {
                count = count + 1
            }
        } catch {
            print(error)
        }
        return count
    }
    

