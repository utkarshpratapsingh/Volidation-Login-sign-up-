//
//  EmailTableViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/22/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit

class EmailTableViewController: UITableViewController {
  
    var email = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
      
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        getEmailData()
        return emailGetData.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        getEmailData()
        let cell: EmailTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell1") as! EmailTableViewCell
        cell.getEmail.text = emailGetData[indexPath.row]
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
               guard let vc = storyboard?.instantiateViewController(identifier: "ShowAllDataViewController") as? ShowAllDataViewController else { return }
        getEmailData()
        //print("phone item is ")
       // print(phoneData[indexPath.item])
        vc.ind = indexPath.item
       present(vc, animated: true, completion: nil)
    }

    
    
    
    
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, handler) in
            //YOUR_CODE_HERE
            
            let alert = UIAlertController(title: "Delete Data", message: "Are you sure you want to delete data?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: {_ in
                //code for delete daa
                //self.email = emailGetData[indexPath.row]
                self.email = emailGetData[indexPath.item]
                deleteRowFormTable(email: self.email)
                print("email: \(self.email)")
                tableView.reloadData()
            }))
            alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: {(_: UIAlertAction!) in
                
            }))
            self.present(alert, animated: true, completion: nil)
            
            
        }
        deleteAction.backgroundColor = .red
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        configuration.performsFirstActionWithFullSwipe = true
        return configuration
    }
    
    override func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let vc = storyboard?.instantiateViewController(identifier: "ShowAllDataViewController") as! ShowAllDataViewController
        
        let editAction = UIContextualAction(style: .normal, title: "View") {(action, view, handler) in
            //code logic
            print("in view")
            vc.ind = indexPath.item
            self.present(vc, animated: true, completion: nil)
        }
        editAction.backgroundColor = .blue
        let configuration = UISwipeActionsConfiguration(actions: [editAction])
        configuration.performsFirstActionWithFullSwipe = true
        return configuration
    }
   
}
