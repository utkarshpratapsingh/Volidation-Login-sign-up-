//
//  PhoneNumberViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit
import CoreData

class PhoneNumberViewController: UIViewController {
    @IBOutlet weak var txtPhoneNumber: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func next4(_ sender: Any) {
        
        if txtPhoneNumber.text!.isPhoneNumber {
            print("Phone Number is valid ")
            someDict["Phone"] = txtPhoneNumber.text!
        }
        else {
            
            let alert = UIAlertController(title: "incorrect", message: "your mobile number  is invalid please enter currect mobil number in", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                self.present(alert, animated: true, completion: nil)
            
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PasswordViewController") as! PasswordViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    

}
