//
//  FirstViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit
import CoreData

class FirstViewController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func next2(_ sender: Any) {
       
        
        if txtFirstName.text!.isName {
                         print("name is valid ")
                         someDict["FastName"] = txtFirstName.text
                     }
                     else {
                         
                         let alert = UIAlertController(title: "incorrect", message: "name should be capital letter", preferredStyle: UIAlertController.Style.alert)
                         alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                             self.present(alert, animated: true, completion: nil)
                         
                     }

        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LastNameViewController") as! LastNameViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
   
}
