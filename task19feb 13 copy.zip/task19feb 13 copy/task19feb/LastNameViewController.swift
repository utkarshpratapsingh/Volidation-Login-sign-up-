//
//  LastNameViewController.swift
//  task19feb
//
//  Created by iPHTech7 on 2/19/21.
//  Copyright © 2021 iPHSTech 7. All rights reserved.
//

import UIKit
import CoreData

class LastNameViewController: UIViewController {

    @IBOutlet weak var txtLastName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func next3(_ sender: Any) {
  
        
        if txtLastName.text!.isName {
            print("name is valid ")
            someDict["LastName"] = txtLastName.text!
        }
        else {
            
            let alert = UIAlertController(title: "incorrect", message: "name should be capital letter", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
                self.present(alert, animated: true, completion: nil)
            
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PhoneNumberViewController") as! PhoneNumberViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
    }
    
    
}
