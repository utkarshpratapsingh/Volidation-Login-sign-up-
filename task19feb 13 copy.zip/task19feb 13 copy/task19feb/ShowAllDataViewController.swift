

import UIKit

class ShowAllDataViewController: UIViewController {
    @IBOutlet weak var showLastName: UILabel!
    var ind = -1
    @IBOutlet weak var showPhone: UILabel!
    @IBOutlet weak var showPassword: UILabel!
    @IBOutlet weak var showDOB: UILabel!
    @IBOutlet weak var showFirstName: UILabel!
    @IBOutlet weak var showEmail: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        showPhone.text = phoneData[ind]
      showEmail.text = emailGetData[ind]
        showDOB.text = dobGetData[ind]
        showFirstName.text = nameGetData[ind]
        showLastName.text = lastGetData[ind]
        showPassword.text = passwordGetData[ind]
        // Do any additional setup after loading the view.
    }
    

    

}
